"use strict";
exports.routes = [
    {
        path: '',
        redirectTo: '/sessions/1',
        pathMatch: 'full'
    }
];
//# sourceMappingURL=app.routing.js.map