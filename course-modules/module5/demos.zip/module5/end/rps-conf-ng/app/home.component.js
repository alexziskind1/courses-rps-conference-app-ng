"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var common_1 = require('@angular/common');
var Rx_1 = require('rxjs/Rx');
var router_2 = require('nativescript-angular/router');
// nativescript
var angular_1 = require('nativescript-telerik-ui/sidedrawer/angular');
var sidedrawer_1 = require('nativescript-telerik-ui/sidedrawer');
var page_1 = require("ui/page");
var sessions_service_1 = require('./services/sessions.service');
var drawer_service_1 = require('./drawer.service');
var static_data_1 = require('./shared/static-data');
var HomeComponent = (function () {
    function HomeComponent(_page, _changeDetectionRef, _router, _routerExtensions, _location, _drawerService, _sessionsService, zone, routerExtensions, route) {
        this._page = _page;
        this._changeDetectionRef = _changeDetectionRef;
        this._router = _router;
        this._routerExtensions = _routerExtensions;
        this._location = _location;
        this._drawerService = _drawerService;
        this._sessionsService = _sessionsService;
        this.zone = zone;
        this.routerExtensions = routerExtensions;
        this.route = route;
        //private _sideDrawerTransition: DrawerTransitionBase;
        //private _drawer: SideDrawerType;
        this.isLoading = false;
        this._selectedIndex = 0;
        this.selectedViewIndex = 1;
        this.actionBarTitle = 'All sessions';
        this.dayHeader = '';
        //public sessions: Observable<Array<SessionModel>>;
        this.sessions = new Rx_1.BehaviorSubject([]);
        _page.on("loaded", this.onLoaded, this);
    }
    Object.defineProperty(HomeComponent.prototype, "confDayOptions", {
        //private _allSessions: Array<SessionModel> = [];
        get: function () {
            return static_data_1.conferenceDays;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HomeComponent.prototype, "selectedIndex", {
        get: function () {
            //console.log('getting selectedIndex');
            return this._selectedIndex;
        },
        set: function (value) {
            //console.log('setting selectedIndex=' + value);
            if (this._selectedIndex !== value) {
                this._selectedIndex = value;
                //this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "selectedIndex", value: value });
                this.dayHeader = static_data_1.conferenceDays[value].desc;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HomeComponent.prototype, "sideDrawerTransition", {
        get: function () {
            //return this._sideDrawerTransition;
            return this._drawerService.sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    HomeComponent.prototype.toggle = function () {
        //this._drawer.toggleDrawerState();
        this._drawerService.toggleDrawerState();
    };
    HomeComponent.prototype.onLoaded = function (args) {
        this._drawerService.sideDrawerTransition = new sidedrawer_1.SlideInOnTopTransition();
        //this._sideDrawerTransition = new SlideInOnTopTransition();
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log('home oninit');
        this.route.params.forEach(function (params) {
            var id = params['id'];
            console.log('home oninit id:' + id);
            _this.selectedViewIndex = parseInt(id);
        });
        this._router.events.subscribe(function (e) {
            if (e instanceof router_1.NavigationEnd) {
                //this._drawer.closeDrawer();
                _this._drawerService.closeDrawer();
            }
        });
        //console.log('list on init. sessionsloaded= ' + this._sessionsService.sessionsLoaded);
        var p = this._sessionsService.loadSessions()
            .then(function (newSessions) {
            //this._allSessions = newSessions.map(s => new SessionModel(s));
            _this.publishUpdates();
        });
    };
    HomeComponent.prototype.publishUpdates = function () {
        var _this = this;
        // Make sure all updates are published inside NgZone so that change detection is triggered if needed
        this.zone.run(function () {
            // must emit a *new* value (immutability!)
            //console.log('in the zone, updating sessions');
            _this.sessions.next(_this._sessionsService.allSessions.slice());
        });
    };
    HomeComponent.prototype.ngAfterViewInit = function () {
        //this._drawer = this.drawerComponent.sideDrawer;
        //this._changeDetectionRef.detectChanges();
        this._drawerService.initDrawer(this.drawerComponent.sideDrawer);
        this._changeDetectionRef.detectChanges();
    };
    HomeComponent.prototype.showActivityIndicator = function () {
        this.isLoading = true;
    };
    HomeComponent.prototype.selectView = function (viewIndex, pageTitle) {
        this.selectedViewIndex = viewIndex;
        this._drawerService.closeDrawer();
        if (this.selectedViewIndex < 2) {
        }
        //this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "selectedViewIndex", value: this.selectedViewIndex });
        //this.set('actionBarTitle', titleText);
        //this.set('isSessionsPage', this.selectedViewIndex < 2);
        this.actionBarTitle = pageTitle;
    };
    HomeComponent.prototype.selectSession = function (args) {
        var session = args.view.bindingContext;
        //hideSearchKeyboard();
        if (!session.isBreak) {
            //console.log('select session ' + session.title);
            var link = ['/details', session.id];
            this.routerExtensions.navigate(link);
        }
    };
    HomeComponent.prototype.toggleFavorite = function (session) {
        session.toggleFavorite();
    };
    HomeComponent.prototype.showSlideout = function (args) {
        this._drawerService.showDrawer();
    };
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent), 
        __metadata('design:type', angular_1.RadSideDrawerComponent)
    ], HomeComponent.prototype, "drawerComponent", void 0);
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'home',
            templateUrl: 'home.component.html',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, core_1.ChangeDetectorRef, router_1.Router, router_2.RouterExtensions, common_1.Location, drawer_service_1.DrawerService, sessions_service_1.SessionsService, core_1.NgZone, router_2.RouterExtensions, router_1.ActivatedRoute])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
///////////////////////////////////////////// 
/*
import { Label } from 'ui/label';
import { StackLayout } from 'ui/layouts/stack-layout';

function navFactoryFunc() {
    var label = new Label();
    label.text = "App created by Nuvious";
        
    var btnBack = new Button();
    btnBack.text = "back";
    btnBack.on('tap', navigationModule.goBack);
    
    var stackLayout = new StackLayout();
    stackLayout.addChild(label);
    stackLayout.addChild(btnBack);

    var dynamicPage = new Page();
    dynamicPage.content = stackLayout;
    return dynamicPage;
};

export function goToAcknowledgementPage() {
    navigationModule.goToPageByFunction(navFactoryFunc);
}

*/ 
//# sourceMappingURL=home.component.js.map