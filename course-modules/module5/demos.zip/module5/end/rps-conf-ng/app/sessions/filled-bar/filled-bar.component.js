"use strict";
// angular
var core_1 = require('@angular/core');
//app
var session_model_1 = require('../shared/session.model');
var FilledBarComponent = (function () {
    function FilledBarComponent() {
    }
    Object.defineProperty(FilledBarComponent.prototype, "fillBar", {
        get: function () {
            return this.fillBarRef.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    FilledBarComponent.prototype.onLoaded = function (args, fillBar) {
        var progressClass = this.getProgressClass(this.session.percentFull);
        if (fillBar.className.indexOf(progressClass) < 0) {
            fillBar.className = fillBar.className + ' ' + progressClass;
        }
    };
    FilledBarComponent.prototype.getProgressClass = function (percentFull) {
        if (percentFull >= 0 && percentFull <= 24)
            return 'level1';
        else if (percentFull >= 25 && percentFull <= 49)
            return 'level2';
        else if (percentFull >= 50 && percentFull <= 74)
            return 'level3';
        else if (percentFull >= 75 && percentFull <= 89)
            return 'level4';
        else if (percentFull >= 90 && percentFull <= 100)
            return 'level5';
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', session_model_1.SessionModel)
    ], FilledBarComponent.prototype, "session", void 0);
    __decorate([
        core_1.ViewChild('fillBar'), 
        __metadata('design:type', core_1.ElementRef)
    ], FilledBarComponent.prototype, "fillBarRef", void 0);
    FilledBarComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'filled-bar',
            templateUrl: 'filled-bar.component.html',
            styleUrls: ['filled-bar.component.css']
        }), 
        __metadata('design:paramtypes', [])
    ], FilledBarComponent);
    return FilledBarComponent;
}());
exports.FilledBarComponent = FilledBarComponent;
//# sourceMappingURL=filled-bar.component.js.map