"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var Rx_1 = require('rxjs/Rx');
// nativescript
var router_2 = require('nativescript-angular/router');
var gestures_1 = require('ui/gestures');
var page_1 = require("ui/page");
var sessions_service_1 = require('../../services/sessions.service');
var room_map_service_1 = require('../../services/room-map.service');
var states = ["unknown", "start", "change", "end"];
var SessionMapComponent = (function () {
    function SessionMapComponent(_page, _sessionsService, _roomMapService, route, routerExtensions) {
        this._page = _page;
        this._sessionsService = _sessionsService;
        this._roomMapService = _roomMapService;
        this.route = route;
        this.routerExtensions = routerExtensions;
        this.startScale = 1;
        this.tempRoomLocPoint = { x: 3505, y: 4473 };
        this.isLoading = false;
        this._page.actionBarHidden = true;
        this._page.backgroundSpanUnderStatusBar = true;
    }
    SessionMapComponent.prototype.getNativeElement = function (ref) {
        return ref.nativeElement;
    };
    Object.defineProperty(SessionMapComponent.prototype, "imageWrapper", {
        get: function () {
            return this.getNativeElement(this.imageWrapperRef);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionMapComponent.prototype, "imgMap", {
        get: function () {
            return this.getNativeElement(this.imgMapRef);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionMapComponent.prototype, "imgPin", {
        get: function () {
            return this.getNativeElement(this.imgPinRef);
        },
        enumerable: true,
        configurable: true
    });
    SessionMapComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.isLoading = true;
            var id = params['id'];
            _this._sessionsService.getSessionById(id)
                .then(function (session) {
                _this.room = session.roomInfo;
                _this.image = Rx_1.Observable.fromPromise(_this._roomMapService.getRoomImage(_this.room));
                _this.image.subscribe(function (observer) {
                    _this.isLoading = false;
                });
            });
        });
    };
    SessionMapComponent.prototype.onImageWrapperLoaded = function () {
        var _this = this;
        var imgWrapperSize = { width: this.imageWrapper.getMeasuredWidth(), height: this.imageWrapper.getMeasuredHeight() };
        var imgSize = { width: this.imgMap.getMeasuredWidth(), height: this.imgMap.getMeasuredHeight() };
        var pinImgSize = { width: this.imgPin.getMeasuredWidth(), height: this.imgPin.getMeasuredHeight() };
        var widthScale = imgSize.width / imgWrapperSize.width;
        var heightScale = imgSize.height / imgWrapperSize.height;
        var largerScale = widthScale > heightScale ? widthScale : heightScale;
        this.imgMap.translateX = imgSize.width / -2;
        this.imgMap.translateY = imgSize.height / -2;
        this.imgPin.scaleX = 3;
        this.imgPin.scaleY = 3;
        this.imgPin.translateX = pinImgSize.width / -3;
        this.imgPin.translateY = pinImgSize.height / -2 + pinImgSize.height * 3 / 4;
        this.imgMap.animate({
            translate: { x: imgSize.width / -2 + imgWrapperSize.width / 2, y: imgSize.height / -2 + imgWrapperSize.height / 2 },
            scale: { x: largerScale / 100, y: largerScale / 100 },
            duration: 1000,
            curve: 'easeInOut'
        })
            .then(function () {
            var imageSizeScaled = { width: imgSize.width / largerScale, height: imgSize.height / largerScale };
            var calcPinLoc = _this.calculatePinImageLocation(_this.tempRoomLocPoint, imgSize, imageSizeScaled, largerScale);
            _this.imgPin.animate({
                translate: { x: pinImgSize.width / -2 + imgWrapperSize.width / 2, y: pinImgSize.height / -2 + imgWrapperSize.height / 2 },
                scale: { x: largerScale / 100, y: largerScale / 100 },
                opacity: 1,
                duration: 1000,
                curve: 'easeOut'
            });
        });
    };
    SessionMapComponent.prototype.calculatePinImageLocation = function (roomLocFullPoint, mapFullSize, pinImgSize, scale) {
        console.log('tScale: ' + scale);
        var newX = roomLocFullPoint.x / scale;
        var newY = roomLocFullPoint.y / scale;
        var roomScaledPoint = { x: newX, y: newY };
        console.dir(roomScaledPoint);
        var pinImageWidthSpecifiedInMarkup = pinImgSize.width;
        var pinImageLocPoint = { x: roomScaledPoint.x - (pinImageWidthSpecifiedInMarkup / 2), y: roomScaledPoint.y - pinImageWidthSpecifiedInMarkup };
        return pinImageLocPoint;
    };
    SessionMapComponent.prototype.backSwipe = function (args) {
        if (args.direction === gestures_1.SwipeDirection.right) {
            this.routerExtensions.backToPreviousPage();
        }
    };
    SessionMapComponent.prototype.backTap = function () {
        this.routerExtensions.backToPreviousPage();
    };
    SessionMapComponent.prototype.onPan = function (args) {
        console.log("PAN[" + states[args.state] + "] deltaX: " + Math.round(args.deltaX) + " deltaY: " + Math.round(args.deltaY));
        if (args.state === 1) {
            this.prevDeltaX = 0;
            this.prevDeltaY = 0;
            if (!this.imageWrapper.translateX) {
                this.imageWrapper.translateX = 0;
            }
            if (!this.imageWrapper.translateY) {
                this.imageWrapper.translateY = 0;
            }
        }
        else if (args.state === 2) {
            this.imageWrapper.translateX = this.imageWrapper.translateX + args.deltaX - this.prevDeltaX;
            this.imageWrapper.translateY = this.imageWrapper.translateY + args.deltaY - this.prevDeltaY;
            this.prevDeltaX = args.deltaX;
            this.prevDeltaY = args.deltaY;
            console.log('tx: ' + this.imageWrapper.translateX);
        }
    };
    SessionMapComponent.prototype.onPinch = function (args) {
        if (args.state === 1) {
            console.log('state: ' + args.state);
            var newOriginX = args.getFocusX() - this.imageWrapper.translateX;
            var newOriginY = args.getFocusY() - this.imageWrapper.translateY;
            var oldOriginX = this.imageWrapper.originX * this.imageWrapper.getMeasuredWidth();
            var oldOriginY = this.imageWrapper.originY * this.imageWrapper.getMeasuredHeight();
            this.imageWrapper.translateX += (oldOriginX - newOriginX) * (1 - this.imageWrapper.scaleX);
            this.imageWrapper.translateY += (oldOriginY - newOriginY) * (1 - this.imageWrapper.scaleY);
            this.imageWrapper.originX = newOriginX / this.imageWrapper.getMeasuredWidth();
            this.imageWrapper.originY = newOriginY / this.imageWrapper.getMeasuredHeight();
            if (this.imageWrapper.scaleX) {
                this.startScale = this.imageWrapper.scaleX;
            }
            else {
                this.imageWrapper.scaleX = 1;
            }
        }
        else if (args.scale && args.scale !== 1) {
            var newScale = this.startScale * args.scale;
            newScale = Math.min(8, newScale);
            newScale = Math.max(0.125, newScale);
            this.imageWrapper.scaleX = newScale;
            this.imageWrapper.scaleY = newScale;
        }
    };
    SessionMapComponent.prototype.onDoubleTap = function (args) {
        console.log("DOUBLETAP:");
        console.dir(args);
        var tx = 0;
        var ty = 0;
        if (this.imageWrapper.scaleX === 1) {
            this.imageWrapper.animate({
                translate: { x: tx * -1, y: ty * -1 },
                scale: { x: 2, y: 2 },
                curve: "easeOut",
                duration: 300
            }).then(function () {
            });
        }
        else {
            this.imageWrapper.animate({
                translate: { x: 0, y: 0 },
                scale: { x: 1, y: 1 },
                curve: "easeOut",
                duration: 300
            }).then(function () {
            });
        }
    };
    __decorate([
        core_1.ViewChild('imageWrapper'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionMapComponent.prototype, "imageWrapperRef", void 0);
    __decorate([
        core_1.ViewChild('imgMap'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionMapComponent.prototype, "imgMapRef", void 0);
    __decorate([
        core_1.ViewChild('imgPin'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionMapComponent.prototype, "imgPinRef", void 0);
    SessionMapComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-map',
            templateUrl: 'session-map.component.html',
            styleUrls: ['session-map.component.css']
        }), 
        __metadata('design:paramtypes', [page_1.Page, sessions_service_1.SessionsService, room_map_service_1.RoomMapService, router_1.ActivatedRoute, router_2.RouterExtensions])
    ], SessionMapComponent);
    return SessionMapComponent;
}());
exports.SessionMapComponent = SessionMapComponent;
//# sourceMappingURL=session-map.component.js.map