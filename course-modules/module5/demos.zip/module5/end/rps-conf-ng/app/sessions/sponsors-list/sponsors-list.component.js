"use strict";
var core_1 = require('@angular/core');
var shared_1 = require('../../shared');
var SponsorsListComponent = (function () {
    function SponsorsListComponent() {
        this.currentState = 'off';
    }
    SponsorsListComponent.prototype.sponsorsWrapperLoaded = function () {
        this.currentState = 'on';
    };
    SponsorsListComponent.prototype.getState = function () {
        return this.currentState;
    };
    SponsorsListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'sponsors-list',
            templateUrl: 'sponsors-list.component.html',
            animations: shared_1.slideInAnimations
        }), 
        __metadata('design:paramtypes', [])
    ], SponsorsListComponent);
    return SponsorsListComponent;
}());
exports.SponsorsListComponent = SponsorsListComponent;
//# sourceMappingURL=sponsors-list.component.js.map