

export class FilterState {

    /*
        public date: number;
        public search: string;
        public viewIndex: number;
    */

    constructor(public date: number, public search: string, public viewIndex: number) {

    }
}