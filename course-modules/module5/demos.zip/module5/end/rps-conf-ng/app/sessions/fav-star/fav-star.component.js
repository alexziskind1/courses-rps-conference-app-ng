"use strict";
//angular
var core_1 = require('@angular/core');
var enums = require('ui/enums');
//app
var session_model_1 = require('../shared/session.model');
var sessions_service_1 = require('../../services/sessions.service');
var FavStarComponent = (function () {
    function FavStarComponent(_sessionsService) {
        this._sessionsService = _sessionsService;
        this.isToggling = false;
    }
    FavStarComponent.prototype.toggleFavorite = function (session, lbl) {
        var _this = this;
        if (this.isToggling) {
            return;
        }
        this.isToggling = true;
        this._sessionsService.toggleFavorite(session)
            .then(function () {
            //done toggling fovaorite
            _this.toggleFavVisual(session, lbl)
                .then(function () {
                _this.isToggling = false;
            });
        });
    };
    FavStarComponent.prototype.toggleFavVisual = function (session, lbl) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (!session.favorite) {
                _this.animateUnfavorite(lbl)
                    .then(function () {
                    resolve();
                });
            }
            else {
                _this.animateFavorite(lbl)
                    .then(function () {
                    resolve();
                });
            }
        });
    };
    FavStarComponent.prototype.animateFavorite = function (lbl) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var x = 0;
            var y = 0;
            var index = 1;
            var cancelId = setInterval(function () {
                _this.setBackgroundPosition(lbl, x + ' ' + y);
                x = x - 50;
                index++;
                if (index == 30) {
                    clearInterval(cancelId);
                    resolve();
                }
            }, 20);
        });
    };
    FavStarComponent.prototype.animateUnfavorite = function (lbl) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.setBackgroundPosition(lbl, '0 0');
            lbl.animate({
                duration: 500,
                scale: { x: 1.5, y: 1.5 },
                curve: enums.AnimationCurve.easeIn
            }).then(function () {
                lbl.animate({
                    duration: 500,
                    scale: { x: 1.0, y: 1.0 },
                    curve: enums.AnimationCurve.easeOut
                }).then(function () {
                    resolve();
                });
            });
        });
    };
    FavStarComponent.prototype.setBackgroundPosition = function (lbl, positionStr) {
        lbl.style.backgroundPosition = positionStr;
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', session_model_1.SessionModel)
    ], FavStarComponent.prototype, "item", void 0);
    FavStarComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'fav-star',
            templateUrl: 'fav-star.component.html',
            styleUrls: ['fav-star.component.css']
        }), 
        __metadata('design:paramtypes', [sessions_service_1.SessionsService])
    ], FavStarComponent);
    return FavStarComponent;
}());
exports.FavStarComponent = FavStarComponent;
//# sourceMappingURL=fav-star.component.js.map