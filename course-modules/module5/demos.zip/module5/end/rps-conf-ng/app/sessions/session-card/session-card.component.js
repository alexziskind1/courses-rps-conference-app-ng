"use strict";
// angular
var core_1 = require('@angular/core');
var platform = require('platform');
//app
var session_model_1 = require('../shared/session.model');
var SessionCardComponent = (function () {
    function SessionCardComponent() {
        this.notifyCardClosed = new core_1.EventEmitter();
    }
    SessionCardComponent.prototype.cardSwipe = function () {
        //close card - an exercise for you!
    };
    SessionCardComponent.prototype.cardClose = function () {
        this.notifyCardClosed.emit();
    };
    SessionCardComponent.prototype.cardLoaded = function (sessionCard) {
        if (platform.isIOS) {
            var nativeIosView = sessionCard.ios;
            nativeIosView.layer.masksToBounds = false;
            nativeIosView.layer.shadowRadius = 10;
            nativeIosView.layer.shadowOpacity = 0.5;
        }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', session_model_1.SessionModel)
    ], SessionCardComponent.prototype, "session", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', core_1.EventEmitter)
    ], SessionCardComponent.prototype, "notifyCardClosed", void 0);
    SessionCardComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-card',
            templateUrl: 'session-card.component.html',
            styleUrls: ['session-card.component.css']
        }), 
        __metadata('design:paramtypes', [])
    ], SessionCardComponent);
    return SessionCardComponent;
}());
exports.SessionCardComponent = SessionCardComponent;
//# sourceMappingURL=session-card.component.js.map