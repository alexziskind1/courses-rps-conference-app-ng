"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var common_1 = require('@angular/common');
var router_2 = require('nativescript-angular/router');
var gestures_1 = require('ui/gestures');
var page_1 = require("ui/page");
var sessions_service_1 = require('./services/sessions.service');
var MapComponent = (function () {
    function MapComponent(_page, _sessionsService, route, location, routerExtensions) {
        this._page = _page;
        this._sessionsService = _sessionsService;
        this.route = route;
        this.location = location;
        this.routerExtensions = routerExtensions;
        this.isLoading = false;
        this._page.actionBarHidden = true;
    }
    MapComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            var id = params['id'];
            console.log('details oninit id:' + id);
            _this._sessionsService.getSessionById(id)
                .then(function (session) {
                _this.room = session.roomInfo;
            });
        });
    };
    MapComponent.prototype.backSwipe = function (args) {
        if (args.direction === gestures_1.SwipeDirection.right) {
            this.routerExtensions.backToPreviousPage();
        }
    };
    MapComponent.prototype.backTap = function () {
        this.routerExtensions.backToPreviousPage();
    };
    MapComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-map',
            templateUrl: 'map.component.html'
        }), 
        __metadata('design:paramtypes', [page_1.Page, sessions_service_1.SessionsService, router_1.ActivatedRoute, common_1.Location, router_2.RouterExtensions])
    ], MapComponent);
    return MapComponent;
}());
exports.MapComponent = MapComponent;
//# sourceMappingURL=map.component.js.map