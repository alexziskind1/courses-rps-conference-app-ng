"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var angular_1 = require('nativescript-telerik-ui/sidedrawer/angular');
var page_1 = require("ui/page");
var button_1 = require('ui/button');
var label_1 = require('ui/label');
var stack_layout_1 = require('ui/layouts/stack-layout');
var animation_1 = require('ui/animation');
var frameModule = require('ui/frame');
var drawer_service_1 = require('../services/drawer.service');
var shared_1 = require('../shared');
var SessionsComponent = (function () {
    function SessionsComponent(_page, _router, _drawerService) {
        this._page = _page;
        this._router = _router;
        this._drawerService = _drawerService;
        this._menuOnClass = 'menu-bar-on';
        this._menuOffClass = 'menu-bar-off';
        this.isLoading = true;
        this.isSessionsPage = true;
        this.actionBarTitle = 'All sessions';
        this.dayHeader = '';
        this.selectedSession = null;
        _page.backgroundSpanUnderStatusBar = true;
        this.selectedIndex = 0;
        this.selectedViewIndex = 1;
    }
    Object.defineProperty(SessionsComponent.prototype, "bar1", {
        get: function () {
            return this.bar1Ref.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionsComponent.prototype, "bar2", {
        get: function () {
            return this.bar2Ref.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionsComponent.prototype, "bar3", {
        get: function () {
            return this.bar3Ref.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionsComponent.prototype, "sessionCardVisible", {
        get: function () {
            return this.selectedSession != null;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionsComponent.prototype, "confDayOptions", {
        get: function () {
            return shared_1.conferenceDays;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionsComponent.prototype, "selectedIndex", {
        get: function () {
            return this._selectedIndex;
        },
        set: function (value) {
            if (this._selectedIndex !== value) {
                this._selectedIndex = value;
                this.dayHeader = shared_1.conferenceDays[value].desc;
            }
        },
        enumerable: true,
        configurable: true
    });
    SessionsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._router.events.subscribe(function (e) {
            if (e instanceof router_1.NavigationEnd) {
                _this._drawerService.closeDrawer();
            }
        });
    };
    Object.defineProperty(SessionsComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._drawerService.sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    SessionsComponent.prototype.startBackgroundAnimation = function (background) {
        var def = {
            scale: { x: 1.0, y: 1.0 },
            duration: 10000,
            target: background
        };
        var ani = new animation_1.Animation([def]);
        ani.play();
    };
    SessionsComponent.prototype.toggle = function () {
        this._drawerService.toggleDrawerState();
    };
    SessionsComponent.prototype.ngAfterViewInit = function () {
        this._drawerService.initDrawer(this.drawerComponent.sideDrawer);
    };
    SessionsComponent.prototype.showActivityIndicator = function () {
        this.isLoading = true;
    };
    SessionsComponent.prototype.selectView = function (viewIndex, pageTitle) {
        this.selectedViewIndex = viewIndex;
        this._drawerService.closeDrawer();
        this.actionBarTitle = pageTitle;
        this.isSessionsPage = this.selectedViewIndex < 2;
    };
    SessionsComponent.prototype.drawerClosing = function (args) {
        //animate menu icon
        if (this._drawerService.IsDrawerOpen) {
            this.animateMenuIcon();
        }
    };
    SessionsComponent.prototype.showSlideout = function (args) {
        this._drawerService.showDrawer();
        //animate menu icon 
        this.animateMenuIcon();
    };
    SessionsComponent.prototype.animateMenuIcon = function () {
        this.toggleClassOnView(this.bar1, this._menuOnClass, this._menuOffClass);
        this.toggleClassOnView(this.bar2, this._menuOnClass, this._menuOffClass);
        this.toggleClassOnView(this.bar3, this._menuOnClass, this._menuOffClass);
    };
    SessionsComponent.prototype.toggleClassOnView = function (view, className1, className2) {
        var newClassName = view.className.trim();
        if (view.className.indexOf(className1) >= 0) {
            newClassName = view.className.replace(className1, '');
            newClassName = newClassName.trim() + ' ' + className2;
        }
        else {
            newClassName = view.className.replace(className2, '');
            newClassName = newClassName.trim() + ' ' + className1;
        }
        view.className = newClassName;
    };
    SessionsComponent.prototype.removeMenuAnimationClasses = function () {
        this.bar1.className = this.bar1.className.replace(this._menuOnClass, '').replace(this._menuOffClass, '');
        this.bar2.className = this.bar2.className.replace(this._menuOnClass, '').replace(this._menuOffClass, '');
        this.bar3.className = this.bar3.className.replace(this._menuOnClass, '').replace(this._menuOffClass, '');
    };
    SessionsComponent.prototype.sessionSelected = function (session) {
        this.selectedSession = session;
    };
    SessionsComponent.prototype.hideSessionCard = function () {
        this.selectedSession = null;
    };
    SessionsComponent.prototype.goToAcknowledgementPage = function () {
        console.log('goToAcknowledgementPage');
        frameModule.topmost().navigate(this.navFactoryFunc);
    };
    SessionsComponent.prototype.navFactoryFunc = function () {
        var label = new label_1.Label();
        label.text = "App created by Nuvious";
        var btnBack = new button_1.Button();
        btnBack.text = "back";
        btnBack.on('tap', frameModule.goBack);
        var stackLayout = new stack_layout_1.StackLayout();
        stackLayout.addChild(label);
        stackLayout.addChild(btnBack);
        var dynamicPage = new page_1.Page();
        dynamicPage.content = stackLayout;
        return dynamicPage;
    };
    ;
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent), 
        __metadata('design:type', angular_1.RadSideDrawerComponent)
    ], SessionsComponent.prototype, "drawerComponent", void 0);
    __decorate([
        core_1.ViewChild('myMenuBtnBar1'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionsComponent.prototype, "bar1Ref", void 0);
    __decorate([
        core_1.ViewChild('myMenuBtnBar2'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionsComponent.prototype, "bar2Ref", void 0);
    __decorate([
        core_1.ViewChild('myMenuBtnBar3'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionsComponent.prototype, "bar3Ref", void 0);
    SessionsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'sessions',
            templateUrl: 'sessions.component.html'
        }), 
        __metadata('design:paramtypes', [page_1.Page, router_1.Router, drawer_service_1.DrawerService])
    ], SessionsComponent);
    return SessionsComponent;
}());
exports.SessionsComponent = SessionsComponent;
//# sourceMappingURL=sessions.component.js.map