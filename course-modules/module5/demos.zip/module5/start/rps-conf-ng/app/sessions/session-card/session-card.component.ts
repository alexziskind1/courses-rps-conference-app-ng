// angular
import { Component, Input, Output, EventEmitter } from '@angular/core';

//app
import { SessionModel } from '../shared/session.model';

@Component({
    moduleId: module.id,
    selector: 'session-card',
    templateUrl: 'session-card.component.html',
    styleUrls: ['session-card.component.css']
})
export class SessionCardComponent {

    @Input() public session: SessionModel;
    @Output() notifyCardClosed: EventEmitter<void> = new EventEmitter<void>();

    public cardSwipe() {
        //close card - an exercise for you!
    }

    public cardClose() {
        this.notifyCardClosed.emit();
    }
}
