"use strict";
var core_1 = require("@angular/core");
exports.slideInAnimations = [
    core_1.trigger('slideIn', [
        core_1.state('on', core_1.style({ transform: 'translate(0, 0)', opacity: 1 })),
        core_1.state('off', core_1.style({ transform: 'translate(-20, 0)', opacity: 0 })),
        core_1.transition('off => on', core_1.animate(600)),
        core_1.transition('* => on', [
            core_1.style({ transform: 'translate(20, 0)', opacity: 0 }),
            core_1.animate(600)
        ])
    ])
];
//# sourceMappingURL=animations.js.map