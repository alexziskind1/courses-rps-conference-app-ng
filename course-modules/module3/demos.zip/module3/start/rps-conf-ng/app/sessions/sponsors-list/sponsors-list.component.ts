import { Component } from '@angular/core';


@Component({
    moduleId: module.id,
    selector: 'sponsors-list',
    templateUrl: 'sponsors-list.component.html'
})
export class SponsorsListComponent {

}