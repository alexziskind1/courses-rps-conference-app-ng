"use strict";
//angular
var core_1 = require('@angular/core');
var Rx_1 = require("rxjs/Rx");
//nativescript
var httpModule = require('http');
//app
var constantsModule = require('../shared/constants');
var fakeDataServiceModule = require('./fake-data.service');
var session_model_1 = require('../sessions/shared/session.model');
var SessionsService = (function () {
    function SessionsService(_zone) {
        this._zone = _zone;
        this.sessionsLoaded = false;
        this._useHttpService = false;
        this._allSessions = [];
        this.items = new Rx_1.BehaviorSubject([]);
    }
    SessionsService.prototype.loadSessions = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            if (_this.sessionsLoaded) {
                resolve(_this._allSessions);
            }
            else {
                if (_this._useHttpService) {
                    return _this.loadSessionsViaHttp()
                        .then(function (newSessions) {
                        _this._allSessions = newSessions.map(function (s) { return new session_model_1.SessionModel(s); });
                        _this.sessionsLoaded = true;
                        resolve(_this._allSessions);
                    });
                }
                else {
                    _this.loadSessionsViaFaker()
                        .then(function (newSessions) {
                        _this._allSessions = newSessions.map(function (s) { return new session_model_1.SessionModel(s); });
                        _this.sessionsLoaded = true;
                        resolve(_this._allSessions);
                    });
                }
            }
        });
    };
    SessionsService.prototype.getSessionById = function (sessionId) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var filtered = _this._allSessions.filter(function (s) { return s.id == sessionId; });
            if (filtered.length > 0) {
                resolve(filtered[0]);
            }
            reject('could not find session with id:' + sessionId);
        });
    };
    SessionsService.prototype.loadSessionsViaHttp = function () {
        var reqParams = {
            url: constantsModule.AZURE_URL + constantsModule.AZURE_TABLE_PATH + constantsModule.AZURE_TABLE_NAME + '?$orderby=start',
            method: 'GET',
            headers: constantsModule.AZURE_VERSION_HEADER
        };
        return httpModule.getJSON(reqParams);
    };
    SessionsService.prototype.loadSessionsViaFaker = function () {
        return new Promise(function (resolve, reject) {
            var speakers = fakeDataServiceModule.generateSpeakers();
            var roomInfos = fakeDataServiceModule.generateRoomInfos();
            var sessions = fakeDataServiceModule.generateSessions(speakers, roomInfos);
            resolve(sessions);
        });
    };
    SessionsService.prototype.update = function (filterState) {
        this._filterState = filterState;
        this.publishUpdates();
    };
    SessionsService.prototype.publishUpdates = function () {
        var _this = this;
        var date = this._filterState.date;
        var search = this._filterState.search;
        var viewIndex = this._filterState.viewIndex;
        var filteredSessions = this._allSessions.filter(function (s) {
            return s.startDt.getDate() === date
                && s.title.toLocaleLowerCase().indexOf(search.toLocaleLowerCase()) >= 0;
        });
        if (viewIndex === 0) {
            filteredSessions = filteredSessions.filter(function (i) { return i.favorite || i.isBreak; });
        }
        // Make sure all updates are published inside NgZone so that change detection is triggered if needed
        this._zone.run(function () {
            // must emit a *new* value (immutability!)
            _this.items.next(filteredSessions.slice());
        });
    };
    SessionsService.prototype.toggleFavorite = function (session) {
        session.toggleFavorite();
        this.publishUpdates();
        return Promise.resolve(true);
    };
    SessionsService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [core_1.NgZone])
    ], SessionsService);
    return SessionsService;
}());
exports.SessionsService = SessionsService;
//# sourceMappingURL=sessions.service.js.map