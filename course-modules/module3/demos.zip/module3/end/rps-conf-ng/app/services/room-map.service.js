"use strict";
var core_1 = require('@angular/core');
var imageSourceModule = require('image-source');
var RoomMapService = (function () {
    function RoomMapService() {
        this._defaultImageSource = imageSourceModule.fromFile('~/images/rooms/conf-map.png');
    }
    RoomMapService.prototype.getRoomImage = function (info) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                resolve(_this._defaultImageSource);
            }, 1000);
        });
    };
    RoomMapService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], RoomMapService);
    return RoomMapService;
}());
exports.RoomMapService = RoomMapService;
//# sourceMappingURL=room-map.service.js.map