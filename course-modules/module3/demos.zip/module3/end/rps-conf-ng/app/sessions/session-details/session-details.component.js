"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var common_1 = require('@angular/common');
var router_2 = require('nativescript-angular/router');
var gestures_1 = require('ui/gestures');
var page_1 = require("ui/page");
//app
var sessions_service_1 = require('../../services/sessions.service');
var SessionDetailsComponent = (function () {
    function SessionDetailsComponent(_page, _sessionsService, route, location, routerExtensions) {
        this._page = _page;
        this._sessionsService = _sessionsService;
        this.route = route;
        this.location = location;
        this.routerExtensions = routerExtensions;
        this.descHeight = 20;
        this._page.actionBarHidden = true;
        this._page.backgroundSpanUnderStatusBar = true;
    }
    SessionDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            var id = params['id'];
            _this._sessionsService.getSessionById(id)
                .then(function (session) {
                _this.session = session;
            });
        });
    };
    SessionDetailsComponent.prototype.backSwipe = function (args) {
        if (args.direction === gestures_1.SwipeDirection.right) {
            this.routerExtensions.backToPreviousPage();
        }
    };
    SessionDetailsComponent.prototype.backTap = function () {
        this.routerExtensions.back();
    };
    SessionDetailsComponent.prototype.showMapTap = function () {
        var link = ['/session-map', this.session.id];
        this.routerExtensions.navigate(link);
    };
    SessionDetailsComponent.prototype.toggleFavorite = function () {
        this._sessionsService.toggleFavorite(this.session)
            .then(function () {
            console.log('done toggling fav from details');
        });
    };
    SessionDetailsComponent.prototype.descWrapperLoaded = function (lblDescWrapper, txtDesc, lblDesc) {
        var lblHeight = lblDesc.getMeasuredHeight();
        this.descHeight = lblHeight;
        lblDesc.visibility = 'collapsed';
        lblDescWrapper.height = 60;
        if (txtDesc.ios) {
            txtDesc.ios.scrollEnabled = false;
        }
        if (txtDesc.android) {
        }
    };
    SessionDetailsComponent.prototype.toogleDescription = function (wrapper) {
        var btn = this.btnDesc.nativeElement;
        var lbl = this.lblDesc.nativeElement;
        if (btn.text === 'MORE') {
            btn.text = 'LESS';
            //lbl.text = this.session.description;
            changeHeight(wrapper, toTheFifth, 1000, 60, this.descHeight);
        }
        else {
            btn.text = 'MORE';
            //lbl.text = this.session.descriptionShort;
            //scroll.scrollToVerticalOffset(0, false);
            changeHeight(wrapper, toTheFifth, 1000, this.descHeight, 60);
        }
    };
    __decorate([
        core_1.ViewChild('btnDesc'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionDetailsComponent.prototype, "btnDesc", void 0);
    __decorate([
        core_1.ViewChild('lblDesc'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionDetailsComponent.prototype, "lblDesc", void 0);
    SessionDetailsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-details',
            templateUrl: 'session-details.component.html',
            styleUrls: ['session-details.component.css']
        }), 
        __metadata('design:paramtypes', [page_1.Page, sessions_service_1.SessionsService, router_1.ActivatedRoute, common_1.Location, router_2.RouterExtensions])
    ], SessionDetailsComponent);
    return SessionDetailsComponent;
}());
exports.SessionDetailsComponent = SessionDetailsComponent;
function changeHeight(view, deltaCalc, duration, from, to) {
    var _from = from || 1;
    var _to = to || 500;
    animate({
        duration: duration || 1000,
        delay: 5,
        delta: deltaCalc,
        step: function (delta) {
            view.height = (to - from) * delta + from;
        }
    });
}
function animate(opts) {
    var start = new Date();
    var id = setInterval(function () {
        var timePassed = (new Date()) - start;
        var progress = timePassed / opts.duration;
        if (progress > 1)
            progress = 1;
        var delta = opts.delta(progress);
        opts.step(delta);
        if (progress == 1) {
            clearInterval(id);
        }
    }, opts.delay || 10);
}
function toTheFifth(progress) {
    return Math.pow(progress, 5);
}
//# sourceMappingURL=session-details.component.js.map