"use strict";
// angular
var core_1 = require('@angular/core');
var drawer_service_1 = require('./drawer.service');
var SomeOtherComponent = (function () {
    function SomeOtherComponent(_drawerService) {
        this._drawerService = _drawerService;
        this.actionBarTitle = 'Sponsors';
    }
    SomeOtherComponent.prototype.showSlideout = function (args) {
        this._drawerService.showDrawer();
    };
    SomeOtherComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'some-other',
            templateUrl: 'some-other.component.html'
        }), 
        __metadata('design:paramtypes', [drawer_service_1.DrawerService])
    ], SomeOtherComponent);
    return SomeOtherComponent;
}());
exports.SomeOtherComponent = SomeOtherComponent;
//# sourceMappingURL=some-other.component.js.map