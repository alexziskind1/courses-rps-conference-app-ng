"use strict";
var FilterState = (function () {
    /*
        public date: number;
        public search: string;
        public viewIndex: number;
    */
    function FilterState(date, search, viewIndex) {
        this.date = date;
        this.search = search;
        this.viewIndex = viewIndex;
    }
    return FilterState;
}());
exports.FilterState = FilterState;
//# sourceMappingURL=filter-state.model.js.map