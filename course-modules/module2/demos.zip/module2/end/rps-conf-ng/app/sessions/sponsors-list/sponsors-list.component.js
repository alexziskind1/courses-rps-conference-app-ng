"use strict";
var core_1 = require('@angular/core');
var SponsorsListComponent = (function () {
    function SponsorsListComponent() {
    }
    SponsorsListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'sponsors-list',
            templateUrl: 'sponsors-list.component.html'
        }), 
        __metadata('design:paramtypes', [])
    ], SponsorsListComponent);
    return SponsorsListComponent;
}());
exports.SponsorsListComponent = SponsorsListComponent;
//# sourceMappingURL=sponsors-list.component.js.map