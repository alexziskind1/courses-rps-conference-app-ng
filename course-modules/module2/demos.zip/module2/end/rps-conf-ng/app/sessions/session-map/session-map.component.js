"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var Rx_1 = require('rxjs/Rx');
// nativescript
var router_2 = require('nativescript-angular/router');
var gestures_1 = require('ui/gestures');
var page_1 = require("ui/page");
var sessions_service_1 = require('../../services/sessions.service');
var room_map_service_1 = require('../../services/room-map.service');
var SessionMapComponent = (function () {
    function SessionMapComponent(_page, _sessionsService, _roomMapService, route, routerExtensions) {
        this._page = _page;
        this._sessionsService = _sessionsService;
        this._roomMapService = _roomMapService;
        this.route = route;
        this.routerExtensions = routerExtensions;
        this.isLoading = false;
        this._page.actionBarHidden = true;
        this._page.backgroundSpanUnderStatusBar = true;
    }
    SessionMapComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.isLoading = true;
            var id = params['id'];
            _this._sessionsService.getSessionById(id)
                .then(function (session) {
                _this.room = session.roomInfo;
                _this.image = Rx_1.Observable.fromPromise(_this._roomMapService.getRoomImage(_this.room));
                _this.image.subscribe(function (observer) {
                    _this.isLoading = false;
                });
            });
        });
    };
    SessionMapComponent.prototype.backSwipe = function (args) {
        if (args.direction === gestures_1.SwipeDirection.right) {
            this.routerExtensions.backToPreviousPage();
        }
    };
    SessionMapComponent.prototype.backTap = function () {
        this.routerExtensions.backToPreviousPage();
    };
    SessionMapComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-map',
            templateUrl: 'session-map.component.html',
            styleUrls: ['session-map.component.css']
        }), 
        __metadata('design:paramtypes', [page_1.Page, sessions_service_1.SessionsService, room_map_service_1.RoomMapService, router_1.ActivatedRoute, router_2.RouterExtensions])
    ], SessionMapComponent);
    return SessionMapComponent;
}());
exports.SessionMapComponent = SessionMapComponent;
//# sourceMappingURL=session-map.component.js.map