"use strict";
// angular
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var common_1 = require('@angular/common');
var router_2 = require('nativescript-angular/router');
var gestures_1 = require('ui/gestures');
var page_1 = require("ui/page");
var sessions_service_1 = require('./services/sessions.service');
var DetailsComponent = (function () {
    function DetailsComponent(_page, _sessionsService, route, location, routerExtensions) {
        this._page = _page;
        this._sessionsService = _sessionsService;
        this.route = route;
        this.location = location;
        this.routerExtensions = routerExtensions;
        this._page.actionBarHidden = true;
    }
    DetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            var id = params['id'];
            console.log('details oninit id:' + id);
            _this._sessionsService.getSessionById(id)
                .then(function (session) {
                _this.session = session;
            });
        });
    };
    DetailsComponent.prototype.backSwipe = function (args) {
        if (args.direction === gestures_1.SwipeDirection.right) {
            this.routerExtensions.backToPreviousPage();
        }
    };
    DetailsComponent.prototype.backTap = function () {
        this.routerExtensions.back();
    };
    DetailsComponent.prototype.showMapTap = function () {
        //console.log('select session ' + session.title);
        var link = ['/map', this.session.id];
        this.routerExtensions.navigate(link);
    };
    DetailsComponent.prototype.toggleFavorite = function () {
        this.session.toggleFavorite();
    };
    DetailsComponent.prototype.toogleDescription = function () {
        var btn = this.btnDesc.nativeElement;
        var lbl = this.lblDesc.nativeElement;
        if (btn.text === 'MORE') {
            btn.text = 'LESS';
            lbl.text = this.session.description;
        }
        else {
            btn.text = 'MORE';
            lbl.text = this.session.descriptionShort;
        }
    };
    __decorate([
        core_1.ViewChild('btnDesc'), 
        __metadata('design:type', core_1.ElementRef)
    ], DetailsComponent.prototype, "btnDesc", void 0);
    __decorate([
        core_1.ViewChild('lblDesc'), 
        __metadata('design:type', core_1.ElementRef)
    ], DetailsComponent.prototype, "lblDesc", void 0);
    DetailsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'session-details',
            templateUrl: 'details.component.html',
            styleUrls: ['details.component.css']
        }), 
        __metadata('design:paramtypes', [page_1.Page, sessions_service_1.SessionsService, router_1.ActivatedRoute, common_1.Location, router_2.RouterExtensions])
    ], DetailsComponent);
    return DetailsComponent;
}());
exports.DetailsComponent = DetailsComponent;
//# sourceMappingURL=details.component.js.map