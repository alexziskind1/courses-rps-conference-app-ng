"use strict";
var home_component_1 = require('./home.component');
var details_component_1 = require('./details.component');
var map_component_1 = require('./map.component');
exports.routes = [
    {
        path: '',
        redirectTo: '/home/1',
        pathMatch: 'full'
    },
    {
        path: "home/:id",
        component: home_component_1.HomeComponent
    },
    {
        path: "details/:id",
        component: details_component_1.DetailsComponent
    },
    {
        path: "map/:id",
        component: map_component_1.MapComponent
    }
];
//# sourceMappingURL=app.routes.js.map