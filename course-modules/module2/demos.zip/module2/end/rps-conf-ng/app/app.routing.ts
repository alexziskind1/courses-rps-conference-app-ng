import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/sessions/1',
    pathMatch: 'full'
  }
];