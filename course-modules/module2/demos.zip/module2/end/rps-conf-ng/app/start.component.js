"use strict";
// angular
var core_1 = require('@angular/core');
var Rx_1 = require('rxjs/Rx');
var router_1 = require('nativescript-angular/router');
var sessions_service_1 = require('./services/sessions.service');
var static_data_1 = require('./shared/static-data');
var drawer_service_1 = require('./drawer.service');
var StartComponent = (function () {
    function StartComponent(_sessionsService, zone, _drawerService, routerExtensions) {
        this._sessionsService = _sessionsService;
        this.zone = zone;
        this._drawerService = _drawerService;
        this.routerExtensions = routerExtensions;
        this._selectedIndex = 0;
        this.actionBarTitle = 'All sessions';
        this.dayHeader = '';
        //public sessions: Observable<Array<SessionModel>>;
        this.sessions = new Rx_1.BehaviorSubject([]);
        this.dayHeader = static_data_1.conferenceDays[this.selectedIndex].desc;
    }
    Object.defineProperty(StartComponent.prototype, "confDayOptions", {
        //private _allSessions: Array<SessionModel> = [];
        get: function () {
            return static_data_1.conferenceDays;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StartComponent.prototype, "selectedIndex", {
        get: function () {
            //console.log('getting selectedIndex');
            return this._selectedIndex;
        },
        set: function (value) {
            //console.log('setting selectedIndex=' + value);
            if (this._selectedIndex !== value) {
                this._selectedIndex = value;
                //this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "selectedIndex", value: value });
                this.dayHeader = static_data_1.conferenceDays[value].desc;
            }
        },
        enumerable: true,
        configurable: true
    });
    StartComponent.prototype.ngOnInit = function () {
        /*
        var p = this._sessionsService.loadSessions<Array<ISession>>();
        this.sessions = Observable.fromPromise(p)
          .map(s => s.map(s1 => new SessionModel(s1)));
          */
        var _this = this;
        console.log('list on init. sessionsloaded= ' + this._sessionsService.sessionsLoaded);
        var p = this._sessionsService.loadSessions()
            .then(function (newSessions) {
            //this._allSessions = newSessions.map(s => new SessionModel(s));
            _this.publishUpdates();
        });
    };
    StartComponent.prototype.publishUpdates = function () {
        var _this = this;
        // Make sure all updates are published inside NgZone so that change detection is triggered if needed
        this.zone.run(function () {
            // must emit a *new* value (immutability!)
            //console.log('in the zone, updating sessions');
            _this.sessions.next(_this._sessionsService.allSessions.slice());
        });
    };
    StartComponent.prototype.selectSession = function (args) {
        var session = args.view.bindingContext;
        //hideSearchKeyboard();
        if (!session.isBreak) {
            //console.log('select session ' + session.title);
            var link = ['/details', session.id];
            this.routerExtensions.navigate(link);
        }
    };
    StartComponent.prototype.toggleFavorite = function (session) {
        session.toggleFavorite();
    };
    StartComponent.prototype.showSlideout = function (args) {
        this._drawerService.showDrawer();
    };
    StartComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'start',
            templateUrl: 'start.component.html',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush
        }), 
        __metadata('design:paramtypes', [sessions_service_1.SessionsService, core_1.NgZone, drawer_service_1.DrawerService, router_1.RouterExtensions])
    ], StartComponent);
    return StartComponent;
}());
exports.StartComponent = StartComponent;
var a = 5;
//# sourceMappingURL=start.component.js.map