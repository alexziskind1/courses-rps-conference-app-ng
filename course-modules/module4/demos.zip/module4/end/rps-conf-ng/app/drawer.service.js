"use strict";
var core_1 = require('@angular/core');
var DrawerService = (function () {
    function DrawerService() {
        this._drawerIsOpen = false;
    }
    Object.defineProperty(DrawerService.prototype, "IsDrawerOpen", {
        get: function () {
            return this._drawerIsOpen;
        },
        set: function (val) {
            this._drawerIsOpen = val;
        },
        enumerable: true,
        configurable: true
    });
    DrawerService.prototype.initDrawer = function (drawer) {
        this._drawer = drawer;
    };
    DrawerService.prototype.toggleDrawerState = function () {
        this._drawerIsOpen = !this._drawerIsOpen;
        this._drawer.toggleDrawerState();
    };
    Object.defineProperty(DrawerService.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        set: function (val) {
            this._sideDrawerTransition = val;
        },
        enumerable: true,
        configurable: true
    });
    DrawerService.prototype.closeDrawer = function () {
        this._drawer.closeDrawer();
    };
    DrawerService.prototype.showDrawer = function () {
        this._drawer.showDrawer();
    };
    DrawerService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DrawerService);
    return DrawerService;
}());
exports.DrawerService = DrawerService;
//# sourceMappingURL=drawer.service.js.map