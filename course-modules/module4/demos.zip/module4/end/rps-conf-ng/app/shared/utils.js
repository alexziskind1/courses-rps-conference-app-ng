"use strict";
function hideSearchKeyboard(searchBar) {
    if (searchBar.android) {
        searchBar.android.clearFocus();
    }
    if (searchBar.ios) {
        searchBar.ios.resignFirstResponder();
    }
}
exports.hideSearchKeyboard = hideSearchKeyboard;
//# sourceMappingURL=utils.js.map