"use strict";
var router_1 = require("@angular/router");
var sessions_component_1 = require("./sessions.component");
var session_details_component_1 = require("./session-details/session-details.component");
var session_map_component_1 = require("./session-map/session-map.component");
var sessionsRoutes = [
    {
        path: "sessions/:id",
        component: sessions_component_1.SessionsComponent
    },
    {
        path: "session-details/:id",
        component: session_details_component_1.SessionDetailsComponent
    },
    {
        path: "session-map/:id",
        component: session_map_component_1.SessionMapComponent
    }
];
exports.sessionsRouting = router_1.RouterModule.forChild(sessionsRoutes);
//# sourceMappingURL=sessions.routing.js.map