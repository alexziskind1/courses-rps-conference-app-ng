"use strict";
//angular
var core_1 = require("@angular/core");
var router_1 = require('nativescript-angular/router');
//app
var sessions_service_1 = require('../../services/sessions.service');
var filter_state_model_1 = require('../shared/filter-state.model');
var shared_1 = require('../../shared');
var SessionListComponent = (function () {
    function SessionListComponent(_sessionsService, _zone, _routerExtensions) {
        this._sessionsService = _sessionsService;
        this._zone = _zone;
        this._routerExtensions = _routerExtensions;
        this._search = '';
        this._selectedIndex = 0;
        this.dayHeader = '';
        this._selectedIndex = 0;
    }
    Object.defineProperty(SessionListComponent.prototype, "selectedViewIndex", {
        get: function () {
            return this._selectedViewIndex;
        },
        set: function (value) {
            this._selectedViewIndex = value;
            if (this._selectedViewIndex < 2) {
                this.refresh();
            }
            this.hideSearchKeyboard();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionListComponent.prototype, "selectedIndex", {
        get: function () {
            return this._selectedIndex;
        },
        set: function (value) {
            if (this._selectedIndex !== value) {
                this._selectedIndex = value;
                this.dayHeader = shared_1.conferenceDays[value].desc;
                if (this.search !== '') {
                    this.search = '';
                }
                else {
                    this.refresh();
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionListComponent.prototype, "search", {
        get: function () {
            return this._search;
        },
        set: function (value) {
            if (this._search !== value) {
                this._search = value;
                this.refresh();
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionListComponent.prototype, "animationState", {
        get: function () {
            return this.selectedViewIndex === 2 ? 'off' : 'on';
        },
        enumerable: true,
        configurable: true
    });
    SessionListComponent.prototype.ngOnInit = function () {
        this._sessionsService.items.subscribe(function (observer) {
            observer.forEach(function (value, i, array) {
                value.triggerShow.next(true);
            });
        });
    };
    SessionListComponent.prototype.load = function () {
        var _this = this;
        var p = this._sessionsService.loadSessions()
            .then(function (newSessions) {
            _this.refresh();
        });
    };
    SessionListComponent.prototype.refresh = function () {
        var filterState = new filter_state_model_1.FilterState(shared_1.conferenceDays[this.selectedIndex].date.getDate(), this.search, this.selectedViewIndex);
        this._sessionsService.update(filterState);
    };
    SessionListComponent.prototype.selectSession = function (args, session) {
        this.hideSearchKeyboard();
        if (!session.isBreak) {
            var link = ['/session-details', session.id];
            this._routerExtensions.navigate(link);
        }
    };
    SessionListComponent.prototype.hideSearchKeyboard = function () {
        shared_1.hideSearchKeyboard(this.searchBar.nativeElement);
    };
    __decorate([
        core_1.ViewChild('searchBar'), 
        __metadata('design:type', core_1.ElementRef)
    ], SessionListComponent.prototype, "searchBar", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SessionListComponent.prototype, "selectedViewIndex", null);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], SessionListComponent.prototype, "selectedIndex", null);
    SessionListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "session-list",
            templateUrl: "session-list.component.html",
            styleUrls: ['session-list.component.css'],
            changeDetection: core_1.ChangeDetectionStrategy.OnPush,
            animations: shared_1.slideInAnimations
        }), 
        __metadata('design:paramtypes', [sessions_service_1.SessionsService, core_1.NgZone, router_1.RouterExtensions])
    ], SessionListComponent);
    return SessionListComponent;
}());
exports.SessionListComponent = SessionListComponent;
//# sourceMappingURL=session-list.component.js.map