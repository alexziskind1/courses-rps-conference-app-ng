// angular
import { Component, ViewChild, Input, ElementRef } from '@angular/core';

// nativescript
import { Label } from 'ui/label';

//app
import { SessionModel } from '../shared/session.model';


@Component({
    moduleId: module.id,
    selector: 'filled-bar',
    templateUrl: 'filled-bar.component.html',
    styleUrls: ['filled-bar.component.css']
})
export class FilledBarComponent {

    @Input() public session: SessionModel;
    @ViewChild('fillBar') public fillBarRef: ElementRef;

    public get fillBar(): Label {
        return this.fillBarRef.nativeElement;
    }

    public onLoaded(args, fillBar: Label) {

    }
}
