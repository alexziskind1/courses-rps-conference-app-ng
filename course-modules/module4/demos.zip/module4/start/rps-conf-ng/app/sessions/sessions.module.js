"use strict";
var platform_1 = require("nativescript-angular/platform");
var forms_1 = require("nativescript-angular/forms");
var core_1 = require("@angular/core");
var angular_1 = require("nativescript-telerik-ui/sidedrawer/angular");
var sessions_routing_1 = require("./sessions.routing");
var sessions_component_1 = require("./sessions.component");
var session_details_component_1 = require("./session-details/session-details.component");
var session_map_component_1 = require("./session-map/session-map.component");
var session_list_component_1 = require("./session-list/session-list.component");
var sponsors_list_component_1 = require("./sponsors-list/sponsors-list.component");
var fav_star_component_1 = require('./fav-star/fav-star.component');
var filled_bar_component_1 = require("./filled-bar/filled-bar.component");
var SessionsModule = (function () {
    function SessionsModule() {
    }
    SessionsModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_1.NativeScriptModule,
                forms_1.NativeScriptFormsModule,
                sessions_routing_1.sessionsRouting
            ],
            declarations: [
                sessions_component_1.SessionsComponent,
                session_details_component_1.SessionDetailsComponent,
                session_map_component_1.SessionMapComponent,
                session_list_component_1.SessionListComponent,
                sponsors_list_component_1.SponsorsListComponent,
                fav_star_component_1.FavStarComponent,
                filled_bar_component_1.FilledBarComponent,
                angular_1.SIDEDRAWER_DIRECTIVES
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], SessionsModule);
    return SessionsModule;
}());
exports.SessionsModule = SessionsModule;
//# sourceMappingURL=sessions.module.js.map